Project 1: Model based Testing using MS Spec Explorer
Part 1
9/15/2012

Shing Jay Ong	ong0@purdue.edu	
Su Lin Ooi 	sooi@purdue.edu
