// THIS FILE WILL BE OVERRIDEN THE FIRST TIME TEST GENERATION IS RUN.
// READ NOTE.txt FOR INSTRUCTIONS HOW TO GENERATE TESTS.

using System;
using System.Collections.Generic;
using System.Text;

using Microsoft.SpecExplorer.Runtime;
using Microsoft.SpecExplorer;

using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Project1.TestSuite
{
    [TestClass]
    public partial class TestSuite 
    {
        [TestMethod]
        public void TestCase0()
        {
            Assert.Inconclusive("Please generate tests from the model.");
        }
    }
}
